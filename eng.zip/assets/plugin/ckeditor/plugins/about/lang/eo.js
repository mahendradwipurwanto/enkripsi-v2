﻿/*
Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'about', 'eo', {
	copy: 'Copyright &copy; $1. Ĉiuj rajtoj rezervitaj.',
	dlgTitle: 'Pri CKEditor 4',
	moreInfo: 'Por informoj pri licenco, bonvolu viziti nian retpaĝaron:'
} );
