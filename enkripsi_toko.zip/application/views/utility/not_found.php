<div class="page-error">
	<div class="page-inner">
		<h1>404</h1>
		<div class="page-description">
			Halaman yang kamu cari tidak dapat ditemukan
		</div>
		<div class="page-search">
			<div class="form-group floating-addon floating-addon-not-append">
				<button class="btn btn-primary btn-lg">
					Halaman tidak ada
				</button>
			</div>
		</div>
		<div class="mt-3">
			<a href="<?= base_url();?>">Kembali kehalaman utama</a>
		</div>
	</div>
</div>
